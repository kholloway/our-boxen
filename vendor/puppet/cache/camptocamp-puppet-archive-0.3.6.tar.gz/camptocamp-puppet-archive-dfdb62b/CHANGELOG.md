## 2015-01-07 - Release 0.3.6

- Fix unquoted strings in cases

## 2015-01-05 - Release 0.3.5

- Simplify bundler cache in Travis CI
- Fix license name in metadata.json

##2014-11-18 Release 0.3.2
- Linting metadata

##2014-11-04 Release 0.3.1
- Fix missing comma

##2014-11-04 Release 0.3.0
- Add path to execs

##2014-11-04 Release 0.2.1
- Drop Puppet 2.7 support

##2014-10-20 Release 0.2.0
### Summary
- Setup automatic Forge releases

##2014-09-24 Release 0.1.3
###Summary
- Bug fix

##2014-09-23 Release 0.1.2
###Summary
- Quote url to get the data from

##2014-09-05 Release 0.1.1
###Summary
- Allow disabling of no-checksum notices in puppetmaster logs

##2014-07-02 Release 0.1.0
###Summary
- Make curl silent, #21
- Add documentation
- Fix strict variables
